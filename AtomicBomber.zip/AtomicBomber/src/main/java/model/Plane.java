package model;

public class Plane {
}
