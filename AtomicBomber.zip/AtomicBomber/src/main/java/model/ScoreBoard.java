package model;

public class ScoreBoard {
}
