package model;

public class User {
    private String username;
    private String password;
    private boolean isGuest;
    private String avatarPath;
    private Game game;
    int score = 0;
    public User(String username, String password, boolean isGuest, String avatarPath) {
        this.username = username;
        this.password = password;
        this.isGuest = isGuest;
        this.avatarPath = avatarPath;
    }
    public String getUsername() {
        return username;
    }
    public String getPassword() {
        return password;
    }
    public boolean isGuest() {
        return isGuest;
    }
    public String getAvatarPath() {
        return avatarPath;
    }
    public void setAvatarPath(String avatarPath) {
        this.avatarPath = avatarPath;
    }
    public Game getGame() {
        return game;
    }
    public void setGame(Game game) {
        this.game = game;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public void setPassword(String password) {
        this.password = password;
    }

}
