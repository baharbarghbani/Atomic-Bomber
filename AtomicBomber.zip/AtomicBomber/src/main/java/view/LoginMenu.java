package view;
import controller.ApplicationController;
import controller.LoginMenuController;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.App;
import model.Result;
import model.User;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static java.util.Objects.requireNonNull;

public class LoginMenu extends Application {
    static Scene currentScene;
    LoginMenuController controller = new LoginMenuController();
    @FXML
    TextField username;
    @FXML
    PasswordField password;

    public static void main(String[] args) {
        try {
            launch(args);
        }catch (Exception e){
            ApplicationController.getStage().show();
        }

    }
    @FXML
    public void initialize(){
            Image icon = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/icon.png")));
            ImageView iconView = new ImageView(icon);
            iconView.setFitHeight(16);
            iconView.setFitWidth(16);
            ApplicationController.getStage().getIcons().add(iconView.getImage());
            if (ApplicationController.loadUsers() != null) {
                ArrayList<User> loadedUsers = new ArrayList<>(ApplicationController.loadUsers());
                App.loadUsers(loadedUsers);
            }
    }

    @Override
    public void start(Stage stage) throws Exception {
        ApplicationController.setStage(stage);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            Pane root = fxmlLoader.load(requireNonNull(getClass().getResource("/FXML/LoginMenuFxml.fxml")));

            // Set the icon for the stage
            stage.setTitle("Login Menu");
            // Create custom title bar layout
            // Set the scene
            currentScene = new Scene(root);
            root.getStyleClass().add("login-menu");
            currentScene.getStylesheets().add(getClass().getResource("/CSS/style.css").toExternalForm());


//            stage.setTitle("Login Menu");
            stage.setScene(currentScene);

            // Show the stage
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void login(){
        Result loginResult  = controller.login(username.getText(), password.getText());
        if (!loginResult.isSuccess()){
            ApplicationController.showAlert(loginResult.getMessage(), "Login Failed!", Alert.AlertType.WARNING);
        }
        else {
            MainMenu mainMenu = new MainMenu();
            try {
                mainMenu.start(ApplicationController.getStage());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    @FXML
    public void signUp(){
        Result result = controller.signUp(username.getText(), password.getText());
        if (!result.isSuccess()){
            ApplicationController.showAlert(result.getMessage(), "Sign up Failed!", Alert.AlertType.WARNING);
        }
        else {
            MainMenu mainMenu = new MainMenu();
            try {
                mainMenu.start(ApplicationController.getStage());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    @FXML
    public void recoverPassword(){
        Result result = controller.recoverPassword(username.getText());
        if (!result.isSuccess()){
            ApplicationController.showAlert(result.getMessage(), "Recover Password Failed!", Alert.AlertType.WARNING);
        }
        else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Recover Password");
            alert.setHeaderText(result.getMessage());
            ImageView imageView = new ImageView(new Image(requireNonNull(getClass().getResourceAsStream("/Images/backgrounds/baharBG3.png"))));
            imageView.setFitWidth(300);
            imageView.setFitHeight(200);
            StackPane dialogPane = new StackPane();
            dialogPane.getChildren().add(imageView);
            alert.getDialogPane().setContent(dialogPane);

            // Apply the background to the header area
            alert.getDialogPane().setStyle("-fx-background-color: transparent;");
            // Set the background of the alert dialog
            alert.getDialogPane().setBackground(new Background(new BackgroundImage(
                    imageView.getImage(),
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.CENTER,
                    BackgroundSize.DEFAULT)));
            alert.showAndWait();
        }
    }
    @FXML
    public void registerAsGuest(){
        Result result = controller.startGameAsGuest();
        ApplicationController.showAlert(result.getMessage(), "Guest Mode", Alert.AlertType.INFORMATION);
        try {
            MainMenu mainMenu = new MainMenu();
            mainMenu.start(ApplicationController.getStage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}