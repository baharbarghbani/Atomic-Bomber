package view;

import controller.ApplicationController;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.App;

import java.util.Objects;

public class MenuController{
    public Image imageInitialize(ImageView imageView) {
        Image icon = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/icon.png")));
        ImageView iconView = new ImageView(icon);
        iconView.setFitHeight(16);
        iconView.setFitWidth(16);
        ApplicationController.getStage().getIcons().add(iconView.getImage());
        if (App.getLoggedInUser() == null) {
            return null;
        }
        String path = App.getLoggedInUser().getAvatarPath();
        return new Image(Objects.requireNonNull(Objects.requireNonNull(getClass().getResourceAsStream(path))));
    }

}
