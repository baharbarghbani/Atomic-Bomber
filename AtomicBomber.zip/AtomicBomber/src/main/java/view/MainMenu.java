package view;

import controller.ApplicationController;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import model.App;
import model.User;

import java.util.Objects;

import static java.util.Objects.requireNonNull;

public class MainMenu extends Application {
    static Scene currentScene;
    @FXML
    public ImageView imageView;
    @FXML
    public Label username;

    public static void main(String[] args) {
        launch(args);
    }
    @FXML
    public void initialize(){
//        Image icon = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/icon.png")));
//        ImageView iconView = new ImageView(icon);
//        iconView.setFitHeight(16);
//        iconView.setFitWidth(16);
//        ApplicationController.getStage().getIcons().add(iconView.getImage());
//        String path = App.getLoggedInUser().getAvatarPath();
//        Image image = new Image(Objects.requireNonNull(Objects.requireNonNull(getClass().getResourceAsStream(path))));
        MenuController mainController = new MenuController();
        Image image = mainController.imageInitialize(imageView);
        imageView.setImage(image);
        username.setStyle("-fx-alignment: center");
        username.setText(App.getLoggedInUser().getUsername());
    }

    @Override
    public void start(Stage stage) throws Exception{

        ApplicationController.setStage(stage);
        FXMLLoader fxmlLoader = new FXMLLoader();
        Pane root = fxmlLoader.load(requireNonNull(getClass().getResource("/FXML/MainMenuFxml.fxml")));

        // Set the icon for the stage
        stage.setTitle("Main Menu");
        // Create custom title bar layout
        // Set the scene
        currentScene = new Scene(root);
        root.getStyleClass().add("main-menu");
        currentScene.getStylesheets().add(getClass().getResource("/CSS/style.css").toExternalForm());
        stage.setScene(currentScene);
        stage.show();
    }
    public void startNewGame(){

    }
    public void continueGame(){

    }
    public void openSettings(){

    }
    public void openScoreBoard(){

    }
    public  void openProfileMenu(){
        ProfileMenu profileMenu = new ProfileMenu();
        try {
            profileMenu.start(ApplicationController.getStage());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public void exit(){
        System.exit(0);
    }

}