package controller;

public class AvatarMenuController {
}
