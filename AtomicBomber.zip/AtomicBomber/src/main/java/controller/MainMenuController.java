package controller;

import view.ProfileMenu;
import view.SettingsMenu;

public class MainMenuController {
    public void openProfileMenu() throws Exception {
        ProfileMenu profileMenu = new ProfileMenu();
        profileMenu.start(ApplicationController.getStage());
    }
    public void openScoreboardMenu() throws Exception {
        // ScoreboardMenu scoreboardMenu = new ScoreboardMenu();
        // scoreboardMenu.start(ApplicationController.getStage());
    }
    public void startNewGame() throws Exception {
        // new GameLauncher().start(ApplicationController.getStage());
    }
    public void openSettings(){
         SettingsMenu settingsMenu = new SettingsMenu();
         try {
                settingsMenu.start(ApplicationController.getStage());
            } catch (Exception e) {
                e.printStackTrace();
         }
    }
}
